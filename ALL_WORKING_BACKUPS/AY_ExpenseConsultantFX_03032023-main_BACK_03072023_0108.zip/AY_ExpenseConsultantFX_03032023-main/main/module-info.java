module guiFX.mainWindows.SPAM {
//    requires javafx.controls;
//    requires javafx.fxml;
    requires java.sql;
    requires java.desktop;



    //opens guiFX.mainWindows to javafx.fxml;
    //exports guiFX.mainWindows;
}