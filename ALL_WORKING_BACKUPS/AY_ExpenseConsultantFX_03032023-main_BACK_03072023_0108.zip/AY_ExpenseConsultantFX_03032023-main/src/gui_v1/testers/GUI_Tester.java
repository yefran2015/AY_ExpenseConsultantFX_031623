package gui_v1.testers;

import gui_v1.mainWindows.MainGUIWindow;

public class GUI_Tester {

	public static void main(String[] args) {
		new MainGUIWindow();

	}

}
