package gui_v1.testers;

import gui_v1.mainWindows.GUI_MainWindow;
import gui_v1.mainWindows.GUI_RecordsWindow;

public class GUI_MainWindowTester {

	public static void main(String[] args) {
//		new GUI_MainWindow();
		GUI_MainWindow.showMainWindow();
	}

}
