package guiFX.controllers;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Label;

import java.text.BreakIterator;

public class MainGUIWindowController {

    public MainGUIWindowController(){
        System.out.println("HHHHH");
    }
}
