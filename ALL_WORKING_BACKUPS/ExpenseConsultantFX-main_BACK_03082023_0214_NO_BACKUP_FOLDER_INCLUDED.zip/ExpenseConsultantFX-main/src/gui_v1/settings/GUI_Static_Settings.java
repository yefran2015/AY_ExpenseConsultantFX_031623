package gui_v1.settings;

public class GUI_Static_Settings {

//    public static  int  workStage = 0;
     public static  int  workStage = 1;

}
