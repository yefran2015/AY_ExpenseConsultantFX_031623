package gui_v1.testers;

import gui_v1.mainWindows.MainGUIWindow;

public class GUI_MainWindowTester {

	public static void main(String[] args) {
		new MainGUIWindow();

	}

}
