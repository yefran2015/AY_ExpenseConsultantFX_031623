package gui_v1.settings;

import java.awt.*;

public interface GUI_LoginSignUpWiindows_Settings {
    String strCopyRigts = "Copyright \u00a9 SPAM Team 2023";

    String strLogInWindowTitle = "Log in";
    String strLogInHeadTitle = "Please Enter Your LogIn Info";

    String strSignUpWindowTitle = "Sign Up new User";
    String StrSignUpHeadTilte = "Please Enter your Info";

    int gui_width = 450;
    int gui_height = 350;
    Dimension logInFFrameSize = new Dimension(gui_width, gui_height);
    Dimension signUpWindowSize = new Dimension(gui_width, gui_height);



}