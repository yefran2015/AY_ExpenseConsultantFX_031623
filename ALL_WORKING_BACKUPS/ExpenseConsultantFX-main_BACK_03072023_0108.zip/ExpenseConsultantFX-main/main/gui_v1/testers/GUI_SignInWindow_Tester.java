package gui_v1.testers;

import gui_v1.login.SignUPWindow;

public class GUI_SignInWindow_Tester {
    public GUI_SignInWindow_Tester(){
        new SignUPWindow();
    }

    public static void main(String[] args) {
        new GUI_SignInWindow_Tester();
    }
}
