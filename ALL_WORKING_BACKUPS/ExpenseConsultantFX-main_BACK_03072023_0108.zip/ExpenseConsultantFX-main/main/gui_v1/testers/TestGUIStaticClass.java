package gui_v1.testers;

public class TestGUIStaticClass {

}
