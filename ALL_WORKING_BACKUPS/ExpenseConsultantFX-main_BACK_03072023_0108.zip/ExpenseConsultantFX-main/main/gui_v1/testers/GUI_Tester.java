package gui_v1.testers;

import gui_v1.mainWindows.GUI_MainWindow;

public class GUI_Tester {

	public static void main(String[] args) {
//		new GUI_MainWindow();
		GUI_MainWindow.showMainWindow();

	}

}
