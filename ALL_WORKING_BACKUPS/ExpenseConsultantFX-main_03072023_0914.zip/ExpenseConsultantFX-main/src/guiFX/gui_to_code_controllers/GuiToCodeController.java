package guiFX.gui_to_code_controllers;

/**
 *
 * @version 0.0.1
 * @serial 02161270
 * @author Andrey Yefremov
 * @author Pavel
 * @author Sam
 * This class is connectrer and controller of flow from GUI to
 * wrok logic code of SPAM Team Appp.
 *
 */
public class GuiToCodeController {

    /**
     * 
     * @param new_login - new users login
     * @param new_pass -- new users password
     */
    public void newUser(String new_login, String new_pass){

    }

    /**
     * @param login  -- existing users login name
     * @param pass -- existiong usders password
     */
    public void logIn(String login, String pass){

    }


}
